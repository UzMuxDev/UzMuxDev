Bot ishlashi uchun serverda "robot" nomli papka hosil qiling va
uni ichiga bots papkasi(ichidagi papka va fayllari bilan) va bot.php faylini joylang!
Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)