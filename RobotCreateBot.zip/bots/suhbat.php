<?php
/*
 * Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)
 */
$admin = "ADMIN_ID";

define('API_KEY', 'API_TOKEN');

function bot($method,$datas=[]){ 
    $url = "https://api.telegram.org/bot".API_KEY."/".$method; 
    $ch = curl_init(); 
    curl_setopt($ch,CURLOPT_URL,$url); 
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas); 
    $res = curl_exec($ch); 
    if(curl_error($ch)){ 
        var_dump(curl_error($ch)); 
    }else{ 
        return json_decode($res); 
    } 
} 

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$cid = $message->chat->id;
$mid = $message->message_id;
$fid = $message->from->id;
$type = $message->chat->type;
$reply = $message->reply_to_message;
$newid = $message->new_chat_member->id;
$botid = bot('getme',['bot'])->result->id;
$botname = bot('getme',['bot'])->result->username;
$rtx = $reply->text;
mkdir("baza");
$msgs = json_decode(file_get_contents("baza/$cid.json"),true);

if($type=="supergroup" or $type=="group"){
    $ex = $msgs[$text];
    $ex = explode("|",$ex);
    $txt = $ex[rand(0,count($ex)-1)];
    bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"$txt",
	'reply_to_message_id'=>$mid
	]);
}

if($rtx){
    if($type=="supergroup"  or $type=="group"){
   	      	if(strpos($msgs[$rtx],"$text") !== false){
   	}else{
		$msgs[$rtx] ="$text|$msgs[$rtx]";
		file_put_contents("baza/$cid.json", json_encode($msgs));
	}
	
}
}

if($text == "/start"){
	bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Salom men guruhingizda suhbatlashaman! Buning uchun meni admin qiling!\n/deldoc - yodlangan so'zlarni tozalash",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]]
    ]
    ])
    ]);
}

if($newid !== NULL and $newid == $botid){
	bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Salom men guruhingizda suhbatlashaman! Buning uchun meni admin qiling!"
	]);
}

$status = bot('getChatMember',[
'chat_id'=>$cid,
'user_id'=>$fid
])->result->status;

if($text=="/deldoc" and ($status=="creator" or $status=="administrator")){
if($type=="supergroup"  or $type=="group"){
unlink("baza/$cid.json");
bot("sendmessage",[
"chat_id"=>$cid,
'parse_mode'=>"markdown",
"text"=>"*🗑 Baza Tozalandi*"
]);
}
}