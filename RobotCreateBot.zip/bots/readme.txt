Oddiy botlar
join
joinhider
like
nick
posbon
reyting
sanash
suhbat