<?php
/*
 * Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)
 */
$admin = "ADMIN_ID";

define('API_KEY', 'API_TOKEN');

function bot($method,$datas=[]){ 
    $url = "https://api.telegram.org/bot".API_KEY."/".$method; 
    $ch = curl_init(); 
    curl_setopt($ch,CURLOPT_URL,$url); 
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); 
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas); 
    $res = curl_exec($ch); 
    if(curl_error($ch)){ 
        var_dump(curl_error($ch)); 
    }else{ 
        return json_decode($res); 
    } 
} 

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$cid = $message->chat->id;
$mid = $message->message_id;
$fid = $message->from->id;
$type = $message->chat->type;
$reply = $message->reply_to_message;
$newid = $message->new_chat_member->id;
$botid = bot('getme',['bot'])->result->id;
$botname = bot('getme',['bot'])->result->username;
$rtx = $reply->text;
mkdir("baza");
$msgs = json_decode(file_get_contents("baza/$cid.json"),true);
$adstep = file_get_contents("admin.step");

if($type=="supergroup" or $type=="group"){
    $get = file_get_contents("grid.txt");
    if(mb_stripos($get, $cid)==false){
        file_put_contents("grid.txt", "$get\n$cid");
    }
    $ex = $msgs[$text];
    $ex = explode("|",$ex);
    $txt = $ex[rand(0,count($ex)-1)];
    bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"$txt",
    'reply_to_message_id'=>$mid
    ]);
}else{
    $get = file_get_contents("usid.txt");
    if(mb_stripos($get, $fid)==false){
        file_put_contents("usid.txt", "$get\n$fid");
    }
}

if($rtx){
    if($type=="supergroup"  or $type=="group"){
            if(strpos($msgs[$rtx],"$text") !== false){
    }else{
        $msgs[$rtx] ="$text|$msgs[$rtx]";
        file_put_contents("baza/$cid.json", json_encode($msgs));
    }
    
}
}

if($text == "/start"){
    bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Salom men guruhingizda suhbatlashaman! Buning uchun meni admin qiling!\n/deldoc - yodlangan so'zlarni tozalash",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]]
    ]
    ])
    ]);
}

if($newid !== NULL and $newid == $botid){
    bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"Salom men guruhingizda suhbatlashaman! Buning uchun meni admin qiling!"
    ]);
}

$status = bot('getChatMember',[
'chat_id'=>$cid,
'user_id'=>$fid
])->result->status;

if($text=="/deldoc" and ($status=="creator" or $status=="administrator")){
if($type=="supergroup"  or $type=="group"){
unlink("baza/$cid.json");
bot("sendmessage",[
"chat_id"=>$cid,
'parse_mode'=>"markdown",
"text"=>"*🗑 Baza Tozalandi*"
]);
}
}

if($text == "/panel" and $cid == $admin){
    bot('deleteMessage',[
    'chat_id' => $cid,
    'message_id' => $mid
    ]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Admin panel! Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
    ]);
}

if($text == "📤 Userlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Userlarga yuboriladigan xabar matnini kiriting(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "us");
}

if($text == "📤 Guruhlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Guruhlarga yuboriladigan xabarni yuboring(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "gr");
}

if($text == "Bekor qilish"){
	unlink("admin.step");
	bot('sendmessage',[
		'chat_id'=>$admin,
		'text'=>"Bekor qilindi! Quyidagi menyudan foydalaning:",
		'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
]);
}

if($adstep == "us" and $text !== "Bekor qilish" and $cid == $admin){
     $userlar = file_get_contents("usid.txt");
     $idszs=explode("\n",$userlar);
     foreach($idszs as $idlat){
        $users = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($users){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha userlarga yuborildi."
        ]);
        }
     }


if($adstep == "gr" and $text !== "Bekor qilish" and $cid == $admin){
        $guruhlar = file_get_contents("grid.txt");
         $idszs=explode("\n",$guruhlar);
          foreach($idszs as $idlat){
          $guruhs = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($guruhs){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha guruhlarga yuborildi."
        ]);
        unlink("admin.step");
      } 
}

if($text == "📊 Statistika" and $cid == $admin){
    $us = file_get_contents("usid.txt");
    $gr = file_get_contents("grid.txt");

    $uscount = substr_count($us, "\n");
    $grcount = substr_count($gr, "\n");
    $count = $uscount + $grcount;

    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"📊 Statistika\n\nUserlar: *$uscount* ta\nGuruhlar: *$grcount* ta\nJami: *$count* ta",
    'parse_mode'=>"markdown"
    ]);
}