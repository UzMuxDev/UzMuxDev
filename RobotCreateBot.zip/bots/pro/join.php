<?php
/*
 * Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)
 */
define('API_KEY', "API_TOKEN"); 

$admin = "ADMIN_ID";

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$capt = $message->caption;
$reply = $message->reply_to_message;
$rfid = $reply->from->id;
$rfname = $reply->from->first_name;
$rmid = $reply->message_id;
$cid = $message->chat->id;
$tx = $message->text;
$text = $message->text;
$name = $message->from->first_name;
$fid = $message->from->id;
$botname = bot('getme',['bot'])->result->username;
$botid = bot('getme',['bot'])->result->id;
$callback = $update->callback_query;
$imid = $callback->inline_message_id;
$data = $callback->data;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cty = $message->chat->type;
$mid = $message->message_id;
$new = $message->new_chat_member;
$newid = $new->id;
$is_bot = $new->is_bot;
$newlng = $new->language_code;
$lng = $message->from->language_code;
$left = $message->left_chat_member;
$leftid = $left->id;
$title = $message->chat->title;
$adstep = file_get_contents("admin.step");
mkdir("channel");

if($newid !== NULL and $newid == $botid){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Salom men guruhingiz a'zolarini kanalingizga a'zo bo'lmagunlaricha yozishga qo'ymayman, buning uchun menga admin berishingiz kerak!*",
        'parse_mode'=>"markdown"
        ]);
}

if($cty == "group" or $cty == "supergroup"){
	$get = file_get_contents("grid.txt");
    if(mb_stripos($get, $cid)==false){
        file_put_contents("grid.txt", "$get\n$cid");
    }
}else{
	$get = file_get_contents("usid.txt");
    if(mb_stripos($get, $fid)==false){
        file_put_contents("usid.txt", "$get\n$fid");
    }
}

if ($tx == "/start" or $tx == "/start@$botname"){
    if($cty == "group" or $cty == "supergroup"){
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid
        ]);
        $st = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Bot lichkasiga yozing*",
        'parse_mode'=>"markdown"
        ]);
        sleep(1);
        $stt = $st->result->message_id;
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$stt
        ]);
    } else {
    bot('sendMessage',[
    'chat_id' => $cid,
    'text' => "Salom <b>$name</b> botimizga xush kelibsiz!\nBu bot guruhingiz a'zolarini kanalingizga a'zo bo'lmagunlaricha yozishga qo'ymaydi!\nBuyruqlar:\n/setchannel - kanalni ulash\n/delchannel - kanalni uzish",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"➕ Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]],
    ]
        ])
    ]);
}
}

if($cty == "group" or $cty == "supergroup"){
if($tx == "/setchannel"){
	$get = bot('getChatMember', [
	'chat_id' => $cid,
	'user_id' => $fid,
	])->result->status;
	if($get =="administrator" or $get == "creator"){
  bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"*⚠️ Ushbu buyruqdan foydalanish quyidagicha:\n\n✅Namuna:*\n`/setchannel @ESoftUz`",
    'parse_mode'=>"markdown",
    'reply_to_message_id'=>$mid
	]);
}
} elseif (mb_stripos($tx, "/setchannel")!== false){
	$kanal = explode(" ", $tx);
	$get = bot('getChatMember',[
    'chat_id'=>$cid,
    'user_id'=>$fid
	])->result->status;
	if($get == "creator" or $get == "administrator"){
	$kanaltekshir = bot('getChatMember',[
    'chat_id'=>$kanal[1],
    'user_id'=>$fid
	])->result->status;
	if($kanaltekshir == "creator" or $kanaltekshir == "administrator"){
	 bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"✅ Kanal sozlandi.\n\nEndi guruh a'zolari $kanal[1] kanaliga a'zo bo'lmaguncha guruhda yoza olishmaydi.",
    'parse_mode'=>"markdown"
	]);
	 file_put_contents("channel/$cid.txt", $kanal[1]);
	} else {
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"*📛 Bot yoki siz kanalda admin emas. Xatolikni to'g'irlab qayta urunib ko'ring!*",
    'parse_mode'=>"markdown",
    'reply_to_message_id'=>$mid
	]);
	}
	}
}
}

$chan = file_get_contents("channel/$cid.txt");

if($chan){
	if((isset($message->text) or isset($message->audio) or isset($message->animation) or isset($message->audio) or isset($message->document) or isset($message->photo) or isset($message->sticker) or isset($message->video) or isset($message->video_note) or isset($message->voice) or isset($message->contact) or isset($message->dice) or isset($message->game) or isset($message->poll) or isset($message->location)) and ($cty == "group" or $cty == "supergroup")){
	if($fid !== 777000){
		$res = bot('getchat', [
		'chat_id'=>$chan
		]);
		$user = $res->result->username;
		$titl = $res->result->title;
		$get = bot('getChatMember',[
        'chat_id'=>$chan,
        'user_id'=>$fid
		])->result->status;

		if($get == "creator" or $get == "administrator" or $get == "member"){}else{
			bot('deleteMessage',[
            'chat_id'=>$cid,
            'message_id'=>$mid
			]);
			bot('sendMessage',[
			'chat_id'=>$cid,
			'text'=>"🔵 Kechirasiz, [$name](tg://user?id=$fid) *$title* guruhida yozish uchun *@$user* kanaliga a'zo bo'lishingiz kerak!",
			'parse_mode'=>"markdown",
			'reply_markup'=>json_encode([
			'inline_keyboard'=>[
			[['text'=>$titl, 'url'=>"https://t.me/".$user]],
			]
			])
			]);
		}
	}
}
}

if($tx == "/delchannel"){
if($cty == "group" or $cty == "supergroup"){
	$us = bot ('getChatMember', [
	'chat_id'=> $cid,
	'user_id'=> $fid,
	])->result->status;
	if ($us == "administrator" or $us == "creator"){
	bot ('sendmessage', [
	'chat_id'=> $cid,
	'parse_mode'=>"markdown",
	'text'=>"🗑Kanal o‘chirib tashlandi!",
	]);

	unlink("channel/$cid.txt");
}
}
}

if($text == "/panel" and $cid == $admin){
    bot('deleteMessage',[
    'chat_id' => $cid,
    'message_id' => $mid
    ]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Admin panel! Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
    ]);
}

if($text == "📤 Userlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Userlarga yuboriladigan xabar matnini kiriting(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "us");
}

if($text == "📤 Guruhlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Guruhlarga yuboriladigan xabarni yuboring(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "gr");
}

if($text == "Bekor qilish"){
	unlink("admin.step");
	bot('sendmessage',[
		'chat_id'=>$admin,
		'text'=>"Bekor qilindi! Quyidagi menyudan foydalaning:",
		'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
]);
}

if($adstep == "us" and $text !== "Bekor qilish" and $cid == $admin){
     $userlar = file_get_contents("usid.txt");
     $idszs=explode("\n",$userlar);
     foreach($idszs as $idlat){
        $users = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($users){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha userlarga yuborildi."
        ]);
        }
     }


if($adstep == "gr" and $text !== "Bekor qilish" and $cid == $admin){
        $guruhlar = file_get_contents("grid.txt");
         $idszs=explode("\n",$guruhlar);
          foreach($idszs as $idlat){
          $guruhs = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($guruhs){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha guruhlarga yuborildi."
        ]);
        unlink("admin.step");
      } 
}

if($text == "📊 Statistika" and $cid == $admin){
    $us = file_get_contents("usid.txt");
    $gr = file_get_contents("grid.txt");

    $uscount = substr_count($us, "\n");
    $grcount = substr_count($gr, "\n");
    $count = $uscount + $grcount;

    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"📊 Statistika\n\nUserlar: *$uscount* ta\nGuruhlar: *$grcount* ta\nJami: *$count* ta",
    'parse_mode'=>"markdown"
    ]);
}