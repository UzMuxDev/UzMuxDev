<?php
/*
 * Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)
 */
define('API_KEY', "API_TOKEN"); 

$admin = "ADMIN_ID";

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function top($chatid){
$text = "👥 <b>TOP 20'ta eng ko'p odam qo'shgan foydalanuvchilar:</b>\n\n";
$files = glob("new/$chatid/*.txt");
foreach ($files as $user) {
$id = str_replace(["new/$chatid/", ".txt"], ["",""],$user);
$data[$id] = file_get_contents($user);
}
arsort($data);
$ar = array_reverse($data);
$i = 1;
foreach ($data as $id=>$pul) {
if ($i > 20)break;
$us = bot ('getChatMember', [
'chat_id'=> $chatid,
'user_id'=> $id,
]);
$res = $us->result->user->first_name;
$text .= "<b>$i)</b> <a href='tg://user?id=$id'>$res</a> <b>- [$pul]</b>\n";
$i++;
}
return $text;
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$capt = $message->caption;
$reply = $message->reply_to_message;
$rfid = $reply->from->id;
$rfname = $reply->from->first_name;
$rmid = $reply->message_id;
$cid = $message->chat->id;
$tx = $message->text;
$text = $message->text;
$name = $message->from->first_name;
$fid = $message->from->id;
$botname = bot('getme',['bot'])->result->username;
$botid = bot('getme',['bot'])->result->id;
$callback = $update->callback_query;
$imid = $callback->inline_message_id;
$data = $callback->data;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cty = $message->chat->type;
$mid = $message->message_id;
$new = $message->new_chat_member;
$newid = $new->id;
$is_bot = $new->is_bot;
$newlng = $new->language_code;
$lng = $message->from->language_code;
$left = $message->left_chat_member;
$leftid = $left->id;
$title = $message->chat->title;
$adstep = file_get_contents("admin.step");
mkdir("new");
if($cty == "group" or $cty == "supergroup"){
mkdir("new/$cid");
}


if($new !== NULL){
  if($newid == $botid){
    bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Salom men guruhingizdagi a'zolar nechta odam qo'shganini aytib beraman.\nBuning uchun meni guruhingizga admin qiling!*",
        'parse_mode'=>"markdown"
    ]);
  }
}

if($cty == "group" or $cty == "supergroup"){
  $get = file_get_contents("grid.txt");
    if(mb_stripos($get, $cid)==false){
        file_put_contents("grid.txt", "$get\n$cid");
    }
}else{
  $get = file_get_contents("usid.txt");
    if(mb_stripos($get, $fid)==false){
        file_put_contents("usid.txt", "$get\n$fid");
    }
}

if ($tx == "/start" or $tx == "/start@$botname"){
    if($cty == "group" or $cty == "supergroup"){
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid
        ]);
        $st = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"*Bot lichkasiga yozing*",
        'parse_mode'=>"markdown"
        ]);
        sleep(1);
        $stt = $st->result->message_id;
        bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$stt
        ]);
    } else {
    bot('sendMessage',[
    'chat_id' => $cid,
    'text' => "Salom <b>$name</b> botimizga xush kelibsiz!\nBu bot guruhingiz a'zolari nechta odam qo'shganligini sanaydi.\nBot buyruqlari:\n/mymembers - siz qo'shgan a'zolar\n/youmembers - reply qilingan odam qo'shgan a'zolar\n/top - top 20 ta eng ko'p odam qo'shgan a'zolar",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"➕ Guruhga qo'shish",'url'=>"https://t.me/$botname?startgroup=new"]],
    ]
        ])
    ]);
}
}

if(isset($new) and $is_bot == false){
    if($newid !== $fid){
    if(file_exists("new/$cid/$fid.txt")){
    $get = file_get_contents("new/$cid/$fid.txt");
    $get += 1;
    file_put_contents("new/$cid/$fid.txt", $get);
    } else {
        $ok = 1;
   file_put_contents("new/$cid/$fid.txt", $ok);
}
}
}

if(isset($left)){
    unlink("new/$cid/$leftid.txt");
}

if($tx == "/mymembers"){
	$get = file_get_contents("new/$cid/$fid.txt");
    
    if($get==true){
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"<a href='tg://user?id=$fid'>$name</a>\n\nSiz <b>$get</b> ta odam qo'shgansiz!",
    'parse_mode'=>"html"
	]);
	} else {
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"<a href='tg://user?id=$fid'>$name</a>\n\nSiz odam qo'shmagansiz!",
    'parse_mode'=>"html"
	]);
	}
}

if($tx == "/youmembers" and isset($reply)){
	$get = file_get_contents("new/$cid/$rfid.txt");
    
    if($get==true){
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"<a href='tg://user?id=$rfid'>$rfname</a>\n\n<b>$get</b> ta odam qo'shgan!",
    'parse_mode'=>"html"
	]);
	} else {
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"<a href='tg://user?id=$rfid'>$rfname</a>\n\nOdam qo'shmagan!",
    'parse_mode'=>"html"
	]);
	}
}

if($tx == "/top" and ($cty == "group" or $cty == "supergroup")){
$rey = top($cid);
bot ('sendMessage', [
'chat_id'=> $cid,
'parse_mode'=>"html",
'text'=> $rey
]);
}

if(isset($update->message->new_chat_member) or isset($update->message->left_chat_member)){
    bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid,
    ]);
}

if($text == "/panel" and $cid == $admin){
    bot('deleteMessage',[
    'chat_id' => $cid,
    'message_id' => $mid
    ]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Admin panel! Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
    ]);
}

if($text == "📤 Userlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Userlarga yuboriladigan xabar matnini kiriting(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "us");
}

if($text == "📤 Guruhlarga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Guruhlarga yuboriladigan xabarni yuboring(markdown):",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"Bekor qilish"]]
    ]
    ])
    ]);

    file_put_contents("admin.step", "gr");
}

if($text == "Bekor qilish"){
  unlink("admin.step");
  bot('sendmessage',[
    'chat_id'=>$admin,
    'text'=>"Bekor qilindi! Quyidagi menyudan foydalaning:",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
            [['text'=>"📤 Userlarga xabar yo'llash"],['text'=>"📤 Guruhlarga xabar yo'llash"]],
            [['text'=>"📊 Statistika"]]
        ]
    ])
]);
}

if($adstep == "us" and $text !== "Bekor qilish" and $cid == $admin){
     $userlar = file_get_contents("usid.txt");
     $idszs=explode("\n",$userlar);
     foreach($idszs as $idlat){
        $users = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($users){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha userlarga yuborildi."
        ]);
        }
     }


if($adstep == "gr" and $text !== "Bekor qilish" and $cid == $admin){
        $guruhlar = file_get_contents("grid.txt");
         $idszs=explode("\n",$guruhlar);
          foreach($idszs as $idlat){
          $guruhs = bot('sendMessage',[
          'chat_id'=>$idlat,
          'text'=>$text,
          'parse_mode'=>"markdown"
          ]);
     }
     if($guruhs){
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"Barcha guruhlarga yuborildi."
        ]);
        unlink("admin.step");
      } 
}

if($text == "📊 Statistika" and $cid == $admin){
    $us = file_get_contents("usid.txt");
    $gr = file_get_contents("grid.txt");

    $uscount = substr_count($us, "\n");
    $grcount = substr_count($gr, "\n");
    $count = $uscount + $grcount;

    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"📊 Statistika\n\nUserlar: *$uscount* ta\nGuruhlar: *$grcount* ta\nJami: *$count* ta",
    'parse_mode'=>"markdown"
    ]);
}