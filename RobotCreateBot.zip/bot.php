<?php
/*
Diqqat bots papkasi va bot.php hostingda "robot" nomli papka ichiga joylashtirilishi kerak
Bo'lmasa botlar ishlamaydi
Dasturchi: Elbek Khamdullaev (https://t.me/KhamdullaevUz)
*/
define('API_KEY',"XXXXXXXXXXX"); 

$admin = "717404897";

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function joinchat($chatid){
    global $name, $cmid;
    $result = bot('getChatMember',[
    'chat_id'=>"-1001289653296",
    'user_id'=>$chatid
    ])->result->status;
    if($result == "creator" or $result == "administrator" or $result == "member"){
        return true;
    } else {
        bot('deleteMessage',[
        'chat_id'=>$chatid,
        'message_id'=>$cmid
        ]); 
        bot('sendMessage',[
        'chat_id'=>$chatid,
        'text'=>"Kechirasiz $name siz bizning kanalimizga a'zo bo'lmasangiz botdan foydalana olmaysiz!\nA'zo bo'lib tekshirish tugmasini bosing!",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
        [['text'=>"➕ A'zo bo'lish",'url'=>"https://t.me/ESoftUz"]],
        [['text'=>"✅ Tekshirish",'callback_data'=>"tekshir"]]
        ]
        ])
        ]);
        return false;
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$cid = $message->chat->id;
$tx = $message->text;
$mid = $message->message_id;
$name = $message->from->first_name;
$fid = $message->from->id;
$callback = $update->callback_query;
$data = $callback->data;
$callid = $callback->id;
$cname = $calback->message->from->first_name;
$ccid = $callback->message->chat->id;
$cmid = $callback->message->message_id;
$cfid = $callback->message->from->id;
$user = $message->from->username;
$botname = bot('getme',['bot'])->result->username;
$inlinequery = $update->inline_query;
$inline_id = $inlinequery->id;
$inlineid = $inlinequery->from->id;
$inline_query = $inlinequery->query;
$adminuser = "@BekDev";
mkdir("referal");
mkdir("stat");
mkdir("step");
mkdir("user");
mkdir("prouser");
mkdir("user/$fid");
mkdir("prouser/$fid");
mkdir("ban");
if(!file_exists("referal/$fid.txt")){  
    file_put_contents("referal/$fid.txt","0");
}

if(file_get_contents("stat/stat.txt")){
} else{
file_put_contents("stat/stat.txt", "0");
}

$referalsum = file_get_contents("referal/$fid.txt");
$referalid = file_get_contents("referal/$fid.referal");
$referalcid = file_get_contents("referal/$ccid.referal");
$userstep = file_get_contents("step/$fid.txt");

$stat = file_get_contents("stat/usid.txt");

$main_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🤖 Bot yaratish"],['text'=>"💰 Hisobim"]],
[['text'=>"🔗 Referal"],['text'=>"💎 Olmos sotib olish"]],
[['text'=>"📚 Qo'llanma"],['text'=>"💵 Narxlar"]],
[['text'=>"ℹ️ Bot haqida"],['text'=>"📊 Statistika"]]
]
]);

$select_menu = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"💠 Oddiy bot"],['text'=>"💎 Pro bot"]],
    [['text'=>"⬅️ Ortga"]]
    ]
    ]);

$bots_menu = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"🖇 Join hider"],['text'=>"🤓 Suhbatdosh"]],
    [['text'=>"🖋 Nik bot"],['text'=>"📈 Reyting bot"]],
    [['text'=>"🛠 Sanovchi bot"],['text'=>"🔗 Join bot"]],
    [['text'=>"👮‍♂️ Posbon bot"],['text'=>"❤️ Channel like"]],
    [['text'=>"⬅️ Ortga"]]
    ]
    ]);

$pro_menu = json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"🖇 Joinhider pro"],['text'=>"🤓 Suhbatdosh pro"]],
    [['text'=>"📈 Reyting pro"],['text'=>"🛠 Sanovchi pro"]],
    [['text'=>"🔗 Join pro"],['text'=>"👮‍♂️ Posbon pro"]],
    [['text'=>"❤️ Like pro"]],
    [['text'=>"⬅️ Ortga"]]
    ]
    ]);

$back_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅️ Ortga"]]
]
]);

$bekor_menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⬅️ Bekor qilish"]]
]
]);

$getss = file_get_contents("ban/banid.txt");
if(mb_stripos($getss, $tx)!==false){
bot('sendMessage',[
'chat_id' => $cid,
'text' => "Kechirasiz <b>$name</b> siz bloklangansiz!",
'parse_mode'=>'html',
]); 
return false;
}

if(isset($message)){
    $get = file_get_contents("stat/usid.txt");
    if(mb_stripos($get,$fid)==false){
        file_put_contents("stat/usid.txt", "$get\n$fid");
        bot('sendMessage',[
          'chat_id'=>"-1001486789888",
          'text'=>"😄 Yangi aʼzo\n👤 Ismi: $name\n🆔 raqami: $fid\n✳️ Usernamesi: @$user\n💡 Lichka: <a href='tg://user?id=$fid'>$name</a>",
          'parse_mode'=>"html"
          ]);
    }
}

if($inlineid !== NULL){
bot('answerInlineQuery',[
    'inline_query_id'=>$inline_id,
    'cache_time'=>1,
    'results'=>json_encode([
    ['type'=>'article',
    'id'=>1,
    'title'=>"Referal havolangizni yuborish uchun bosing",
    'input_message_content'=>[
    'disable_web_page_preview'=>true,
    'parse_mode'=>'MarkDown',
    'message_text'=>"🧐 Bot yaratishni xohlaysiz ammo dasturlash tillarini yaxshi bilmaysizmi? 😕 Yoki yaxshi hosting topa olmayapsizmi?
😊 Unda sizga bir botni taklif qilaman!
👉 Quyidagi havola orqali botga tashrif buyuring: https://t.me/$botname?start=$inlineid
☺️ Taqdim etilgan kanalga a'zo bo'lib, bot yaratishni hoziroq boshlang!",
    ],
    'reply_markup'=>[
     'inline_keyboard'=>[
     [['text'=>"Botga kirish",'url'=>"https://t.me/$botname?start=$inlineid"]]
     ]
     ]
     ],
])
]);
}

if ($tx == "/start"){
    if(joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id' => $cid,
    'text' => "Salom <b>$name</b> botimizga xush kelibsiz!\n\nSiz bizning botimiz orqali o'zingizga bot yaratib olishingiz mumkin!\nBuning uchun sizdan hech qanaqa hosting va dasturlash tili talab etilmaydi!\n\nQuyidagi menyudan foydalaning 👇",
    'parse_mode'=>'html',
    'reply_markup'=>$main_menu
    ]);
}
} elseif (mb_stripos($tx, "/start")!==false) {
    if(joinchat($fid)=="true"){
        bot('sendMessage',[
        'chat_id' => $cid,
        'text' => "Salom <b>$name</b> botimizga xush kelibsiz!\n\nSiz bizning botimiz orqali o'zingizga bot yaratib olishingiz mumkin!\nBuning uchun sizdan hech qanaqa hosting va dasturlash tili talab etilmaydi!\n\nQuyidagi menyudan foydalaning 👇",
        'parse_mode'=>'html',
        'reply_markup'=>$main_menu
        ]);
        
        if(mb_stripos($stat, $fid)==false){
        $ex = explode(" ", $tx);
        if($ex[1] == $cid){
        }else{
        $olmos = file_get_contents("referal/$ex[1].txt");
        $olmoslar = $olmos + 2;
        file_put_contents("referal/$ex[1].txt", $olmoslar);
        bot('sendMessage',[
        'chat_id'=>$ex[1],
        'text'=>"Tabriklaymiz siz botimizga do'stingizni taklif qildingiz va do'stingiz kanalimizga a'zo bo'ldi buning uchun sizga <b>2</b> ta 💎 olmos berildi!",
        'parse_mode'=>'html'
        ]);
        }
        }

    }else{
        if(mb_stripos($stat, $fid)==false){      
        $ex = explode(" ", $tx);
        if($ex[1] == $cid){
        }else{
        bot('sendMessage',[
        'chat_id'=>$ex[1],
        'text'=>"Tabriklaymiz siz botimizga do'stingizni taklif qildingiz! Ammo do'stingiz kanalimizga hali a'zo bo'lmadi. Do'stingiz kanalimizga a'zo bo'lsa sizga <b>2</b> ta 💎 olmos beriladi!",
        'parse_mode'=>'html'
        ]);
        file_put_contents("referal/$fid.referal", $ex[1]);
    }
    }else{
        unlink("referal/$fid.referal");
    }
    }
}


if($data == "tekshir"){
    if(joinchat($ccid) == "true"){
        bot('deleteMessage',[
        'chat_id'=>$ccid,
        'message_id'=>$cmid
        ]); 

        if($referalcid == true){
        $olmos = file_get_contents("referal/$referalcid.txt");
        $olmoslar = $olmos + 2;
        file_put_contents("referal/$referalcid.txt", $olmoslar);
         bot('sendMessage',[
        'chat_id'=>$referalcid,
        'text'=>"Tabriklaymiz do'stingiz kanalimizga a'zo bo'ldi va sizga <b>2</b> ta 💎 olmos berildi! ",
        'parse_mode'=>'html'
        ]);
         unlink("referal/$ccid.referal");
     }

        bot('sendMessage',[
        'chat_id'=>$ccid,
        'text'=>"<b>Yaxshi siz bizning kanalimizga a'zo bo'ldingiz!</b>\n\nSiz bizning botimiz orqali o'zingizga bot yaratib olishingiz mumkin!\nBuning uchun sizdan hech qanaqa hosting va dasturlash tili talab etilmaydi!\n\nQuyidagi menyudan foydalaning 👇",
        'parse_mode'=>"html",
        'reply_markup'=>$main_menu
        ]);
    }else{
        bot("answerCallbackQuery",[
        "callback_query_id"=>$callid,
        "text"=>"Siz hali kanalimizga aʼzo boʻlmadingiz!",
        "show_alert"=>true,
        ]);
    }
}

if($tx == "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    unlink("step/$fid.txt");
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"📛 <b>Bekor qilindi!</b>\n\nQuyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$main_menu
    ]);
}

if($tx == "⬅️ Ortga" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi menyudan foydalaning 👇",
    'parse_mode'=>"html",
    'reply_markup'=>$main_menu
    ]);
}

if($tx == "🤖 Bot yaratish" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Qanday turdagi bot yaratamiz 👇",
    'reply_markup'=>$select_menu
    ]);
}

if($tx == "💠 Oddiy bot"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Demak oddiy bot yasaymiz. Quyidagi botlar ichidan birini tanlang 👇",
'reply_markup'=>$bots_menu
]);
}

if($tx == "💎 Pro bot"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"Demak pro bot yasaymiz. Quyidagi botlar ichidan birini tanlang 👇",
'reply_markup'=>$pro_menu
]);	
}

if($tx == "💰 Hisobim" and joinchat($fid)=="true"){
    $get = file_get_contents("referal/$fid.txt");
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Sizda <b>$get</b> ta olmos bor",
    'parse_mode'=>"html",
    'reply_markup'=>$back_menu
    ]);
}

if($tx == "🔗 Referal" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
}

if($tx == "💎 Olmos sotib olish" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Olmos sotib olish uchun $adminuser'ga murojaat qiling!\n1 ta olmos narxi 250 so'm\nTo'lov turlari: Uzmobile perevod, Click, Paynet",
    'parse_mode'=>"html",
    'reply_markup'=>$back_menu
    ]);
}
### FREE BOTS
//----------------------------------
if($tx == "🖇 Join hider" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","joinh&token");
}

if($userstep == "joinh&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/joinhider.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/joinhider");
    if(file_get_contents("user/$fid/joinhider/joinhider.php")){
        unlink("user/$fid/joinhider/joinhider.php");
    }
    file_put_contents("user/$fid/joinhider/joinhider.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/joinhider/joinhider.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Join hider bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//----------------------------------
if($tx == "🤓 Suhbatdosh" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","suhbat&token");
}

if($userstep == "suhbat&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/suhbat.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/suhbat");
    if(file_get_contents("user/$fid/suhbat/suhbat.php")){
        unlink("user/$fid/suhbat/suhbat.php");
        $files = glob("user/$fid/suhbat/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("user/$fid/suhbat/baza");
    }
    file_put_contents("user/$fid/suhbat/suhbat.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/suhbat/suhbat.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Suhbatdosh bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//----------------------------------
if($tx == "🖋 Nik bot" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","nik&token");
}

if($userstep == "nik&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/nick.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/nick");
    if(file_get_contents("user/$fid/nick/nick.php")){
        unlink("user/$fid/nick/nick.php");
    }
    file_put_contents("user/$fid/nick/nick.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/nick/nick.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Nick bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {     
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);   
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//----------------------------------
if($tx == "📈 Reyting bot" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","rey&token");
}

if($userstep == "rey&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/reyting.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/reyting");
    if(file_get_contents("user/$fid/reyting/reyting.php")){
        $files = glob("user/$fid/reyting/*");
        foreach ($files as $value) {
            unlink($value);
        }
        $fils = glob("user/$fid/reyting/reyting/*");
        foreach ($fils as $valu) {
            $fayl = glob("$valu/*");
            foreach ($fayl as $key) {
             unlink($key);   
            }
            rmdir($valu);
        }
        rmdir("user/$fid/reyting/reyting");
    }
    file_put_contents("user/$fid/reyting/reyting.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/reyting/reyting.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Reyting bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);

        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {      
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//----------------------------------
if($tx == "🛠 Sanovchi bot" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","sanash&token");
}

if($userstep == "sanash&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/sanash.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/sanash");
    if(file_get_contents("user/$fid/sanash/sanash.php")){
        $files = glob("user/$fid/sanash/new/*");
        foreach ($files as $value) {
            $papka = glob("$value/*");
            foreach ($papka as $key) {
                unlink($key);
            }
            rmdir($value);
        }
        rmdir("user/$fid/sanash/new");
    }
    file_put_contents("user/$fid/sanash/sanash.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/sanash/sanash.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Sanovchi bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);  
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//----------------------------------
if($tx == "🔗 Join bot" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","join&token");
}

if($userstep == "join&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/join.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/join");
    if(file_get_contents("user/$fid/join/join.php")){
        $files = glob("user/$fid/join/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/join/channel");
    }
    file_put_contents("user/$fid/join/join.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/join/join.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Join bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############

//---------
if($tx == "👮‍♂️ Posbon bot"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","posbon&token");
}

if($userstep == "posbon&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/posbon.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/posbon");
    if(file_get_contents("user/$fid/posbon/posbon.php")){
        $files = glob("user/$fid/posbon/warn/*");
        foreach ($files as $value) {
            $file = glob("$value/*");
            foreach ($file as $key) {
                unlink($key);
            }
            rmdir($value);
        }
        rmdir("user/$fid/posbon/warn");

        $files2 = glob("user/$fid/posbon/new/*");
        foreach ($files2 as $value2) {
            $file2 = glob("$value2/*");
            foreach ($file2 as $key2) {
                unlink($key2);
            }
            rmdir($value2);
        }
        rmdir("user/$fid/posbon/new");

        $files3 = glob("user/$fid/posbon/channel/*");
        foreach ($files3 as $value3) {
            unlink($value3);
        }
        rmdir("user/$fid/posbon/channel");

        $files4 = glob("user/$fid/posbon/sozlama/*");
        foreach ($files4 as $value4) {
            unlink($value4);
        }
        rmdir("user/$fid/posbon/sozlama");

        $files5 = glob("user/$fid/posbon/stat/*");
        foreach ($files5 as $value5) {
            unlink($value5);
        }
        rmdir("user/$fid/posbon/stat");

        
    }
    file_put_contents("user/$fid/posbon/posbon.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/posbon/posbon.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Posbon bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}

###

//---------
if($tx == "❤️ Channel like"){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","channel&token");
}

if($userstep == "channel&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/like.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("user/$fid/like");
    if(file_get_contents("user/$fid/like/like.php")){
        $files = glob("user/$fid/like/like/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/like");
        $files = glob("user/$fid/like/baza/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("user/$fid/like/baza");
    }
    file_put_contents("user/$fid/like/like.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/user/$fid/like/like.php"))->result;

    if($get==true){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Channel like bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $getssss = file_get_contents("stat/stat.txt");
        $getssss += 1;
        file_put_contents("stat/stat.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
###

############# PRO_BOTS #############
//--------------------------------------
if($tx == "🖇 Joinhider pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 10){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Joinhider pro bot yaratish uchun 10 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","joinhpro&token");
    }
}

if($userstep == "joinhpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/joinhider.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/joinhider");
    if(file_get_contents("prouser/$fid/joinhider/joinhider.php")){
        unlink("prouser/$fid/joinhider/joinhider.php");
        unlink("prouser/$fid/joinhider/usid.txt");
        unlink("prouser/$fid/joinhider/grid.txt");
    }
    file_put_contents("prouser/$fid/joinhider/joinhider.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/joinhider/joinhider.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Joinhider pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n<code>/panel</code> - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 10;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############
//--------------------------------------
if($tx == "🤓 Suhbatdosh pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 12){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Suhbatdosh pro bot yaratish uchun 12 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","suhbatpro&token");
    }
}

if($userstep == "suhbatpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
        $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id;
    $kod = file_get_contents("bots/pro/suhbat.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/suhbat");
    if(file_get_contents("prouser/$fid/suhbat/suhbat.php")){
        unlink("prouser/$fid/suhbat/suhbat.php");
        unlink("prouser/$fid/suhbat/usid.txt");
        unlink("prouser/$fid/suhbat/grid.txt");
        $files = glob("prouser/$fid/suhbat/baza/*");
        foreach ($files as $key) {
        	unlink($key);
        }
        rmdir("prouser/$fid/suhbat/baza");
    }
    file_put_contents("prouser/$fid/suhbat/suhbat.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/suhbat/suhbat.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Suhbatdosh pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 12;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);        
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
#############
//-----------------------------------
if($tx == "📈 Reyting pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 14){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Reyting pro bot yaratish uchun 14 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","reypro&token");
    }
}

if($userstep == "reypro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/reyting.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/reyting");
    if(file_get_contents("prouser/$fid/reyting/reyting.php")){
    	unlink("prouser/$fid/reyting/reyting.php");
    	unlink("prouser/$fid/reyting/usid.txt");
    	unlink("prouser/$fid/reyting/grid.txt");
        $files = glob("prouser/$fid/reyting/*");
        foreach ($files as $value) {
            unlink($value);
        }
        $fils = glob("prouser/$fid/reyting/reyting/*");
        foreach ($fils as $valu) {
            $fayl = glob("$valu/*");
            foreach ($fayl as $key) {
             unlink($key);   
            }
            rmdir($valu);
        }
        rmdir("prouser/$fid/reyting/reyting");
    }
    file_put_contents("prouser/$fid/reyting/reyting.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/reyting/reyting.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Reyting pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 14;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {      
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}

##################
if($tx == "🛠 Sanovchi pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 16){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Sanovchi pro bot yaratish uchun 16 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","sanashpro&token");
    }
}

if($userstep == "sanashpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/sanash.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/sanash");
    if(file_get_contents("prouser/$fid/sanash/sanash.php")){
    	unlink("prouser/$fid/sanash/sanash.php");
    	unlink("prouser/$fid/sanash/usid.txt");
    	unlink("prouser/$fid/sanash/grid.txt");
        $files = glob("prouser/$fid/sanash/new/*");
        foreach ($files as $value) {
            $papka = glob("$value/*");
            foreach ($papka as $key) {
                unlink($key);
            }
            rmdir($value);
        }
        rmdir("prouser/$fid/sanash/new");
    }
    file_put_contents("prouser/$fid/sanash/sanash.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/sanash/sanash.php"))->result;

    if($get){
        $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Sanovchi pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 16;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);  
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}


//-----------------------------------------------

if($tx == "🔗 Join pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 18){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Join pro bot yaratish uchun 18 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","joinpro&token");
    }
}

if($userstep == "joinpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/join.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/join");
    if(file_get_contents("prouser/$fid/join/join.php")){
    	unlink("prouser/$fid/join/join.php");
    	unlink("prouser/$fid/join/usid.txt");
    	unlink("prouser/$fid/join/grid.txt");    	
        $files = glob("prouser/$fid/join/channel/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("prouser/$fid/join/channel");
    }
    file_put_contents("prouser/$fid/join/join.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/join/join.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Join bot\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 18;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}
################

//-----------------------------------

if($tx == "👮‍♂️ Posbon pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 20){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Posbon pro bot yaratish uchun 20 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","posbonpro&token");
    }
}

if($userstep == "posbonpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/posbon.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/posbon");
    if(file_get_contents("prouser/$fid/posbon/posbon.php")){
    	unlink("prouser/$fid/posbon/posbon.php");
    	unlink("prouser/$fid/posbon/grid.txt");
    	unlink("prouser/$fid/posbon/usid.txt");
        $files = glob("prouser/$fid/posbon/warn/*");
        foreach ($files as $value) {
            $file = glob("$value/*");
            foreach ($file as $key) {
                unlink($key);
            }
            rmdir($value);
        }
        rmdir("prouser/$fid/posbon/warn");

        $files2 = glob("prouser/$fid/posbon/new/*");
        foreach ($files2 as $value2) {
            $file2 = glob("$value2/*");
            foreach ($file2 as $key2) {
                unlink($key2);
            }
            rmdir($value2);
        }
        rmdir("prouser/$fid/posbon/new");

        $files3 = glob("prouser/$fid/posbon/channel/*");
        foreach ($files3 as $value3) {
            unlink($value3);
        }
        rmdir("prouser/$fid/posbon/channel");

        $files4 = glob("prouser/$fid/posbon/sozlama/*");
        foreach ($files4 as $value4) {
            unlink($value4);
        }
        rmdir("prouser/$fid/posbon/sozlama");

        $files5 = glob("prouser/$fid/posbon/stat/*");
        foreach ($files5 as $value5) {
            unlink($value5);
        }
        rmdir("prouser/$fid/posbon/stat");

        
    }
    file_put_contents("prouser/$fid/posbon/posbon.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/posbon/posbon.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Posbon pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $gett = file_get_contents("referal/$fid.txt");
        $gett -= 20;
        file_put_contents("referal/$fid.txt", $gett);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}

##########################

//-----------------------------
if($tx == "❤️ Like pro"){
	$get = file_get_contents("referal/$fid.txt");
	if($get < 22){
    bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"Like pro bot yaratish uchun 22 ta olmos kerak. Quyidagi havolani do'stlaringizga tarqatib olmos yig'ing:\n<code>https://t.me/$botname?start=$cid</code>\n\nEslatib o'tamiz har bir do'stingiz sizga <b>2</b> ta olmos beradi!\nDo'stingiz kanalimizga a'zo bo'lmasa sizga olmos berilmaydi!\nYoki $adminuser'ga murojaat qilib olmos sotib oling!",
    'parse_mode'=>"html",
    'disable_web_page_preview'=>true,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
    [['text'=>"Referalni tarqatish",'switch_inline_query'=>"$fid"]]
    ]
    ])
    ]);
	}else{
	bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"@BotFather'dan olgan API TOKEN ni yuboring:",
    'reply_markup'=>$bekor_menu
    ]);
    file_put_contents("step/$fid.txt","channelpro&token");
    }
}

if($userstep == "channelpro&token" and $tx !== "⬅️ Bekor qilish" and joinchat($fid)=="true"){
    if(mb_stripos($tx, ":")!==false){
    $getid = bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"Tayyorlanmoqda..."
        ])->result->message_id; 
    $kod = file_get_contents("bots/pro/like.php");
    $kod = str_replace("API_TOKEN", "$tx", $kod);
    $kod = str_replace("ADMIN_ID", "$fid", $kod);
    
    mkdir("prouser/$fid/like");
    if(file_get_contents("prouser/$fid/like/like.php")){
    	unlink("prouser/$fid/like/like.php");
    	unlink("prouser/$fid/like/usid.txt");
    	unlink("prouser/$fid/like/grid.txt");
        $files = glob("prouser/$fid/like/like/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("prouser/$fid/like/like");
        $files = glob("prouser/$fid/like/baza/*");
        foreach ($files as $value) {
            unlink($value);
        }
        rmdir("prouser/$fid/like/baza");
    }
    file_put_contents("prouser/$fid/like/like.php", $kod);

    $get = json_decode(file_get_contents("https://api.telegram.org/bot$tx/setwebhook?url=https://".$_SERVER['SERVER_NAME']."/robot/prouser/$fid/like/like.php"))->result;

    if($get){
         $user = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->username;
        $nomi = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->first_name;
        $id = json_decode(file_get_contents("https://api.telegram.org/bot$tx/getme"))->result->id;
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]);
        bot('sendMessage',[
        'chat_id'=>$cid,
        'message_id'=>$getid,
        'text'=>"✅ Bot tayyor!\n\n💡 Bot turi: Channel like pro\n👤 Bot nomi: $nomi\n✳️ Useri: @$user\n🆔 raqami: $id\n\n/panel - admin panel",
        'parse_mode'=>"html",
        'reply_markup'=>$back_menu
        ]);
        $get = file_get_contents("referal/$fid.txt");
        $get -= 22;
        file_put_contents("referal/$fid.txt",$get);
        $getssss = file_get_contents("stat/statpro.txt");
        $getssss += 1;
        file_put_contents("stat/statpro.txt", $getssss);
    } else {        
        bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$getid]); 
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Noma'lum xatolik",
        'parse_mode'=>"html"
        ]);
    }

    unlink("step/$fid.txt");
   }else{
        bot('sendMessage',[
        'chat_id'=>$cid,
        'text'=>"📛 Menimcha siz tokenni yuborishda xatolikk yo'l qo'ydingiz!\nToken to'g'riligiga ishonch hosil qilib, qayta yuboring!",
        'parse_mode'=>"html"
        ]);
   }
}


#############################################-END-###########################


if($tx == "📚 Qo'llanma" and joinchat($fid)=="true"){

bot('sendMessage',[
    'chat_id'=>$cid,
    'text'=>"🔮 Bot yaratish qo'llanmasi!

1. Telegram dasturingizdan @BotFather deb qidiring va START tugmasini bosing!

2. @BotFather ga /newbot buyrug'ini yozing.

3. Yaratmoqchi bo'lgan botingiz NOMINI yozing.

4. Botingiz BOTNAMEsini yozing (botname oxiri  bot  yoki robot bilan tugashi kerak).

5. Agar amallarni to'g'ri bajargan bo'lsangiz sizga @BotFather botingiz Tokenini yuboradi uni saqlab qo'ying!

6. Bot yaratayotganingizda botimiz Token so'raganida @BotFather yuborgan tokeni yuborasiz

➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖

*ESLATMA:*

*Agarda siz ikkita bir xil bot yaratgan bo'lsangiz avval yaratgan botingiz ish faoliyati to'xtaydi va yangi botingiz ishlashni boshlaydi!*",
'parse_mode'=>"markdown",
'reply_markup'=>$back_menu
]);
}

if($tx == "💵 Narxlar" and joinchat($fid)=="true"){
    bot('sendMessage',[
    'chat_id' => $cid,
    'text'=>"💠 Oddiy botlar tekin ☺️

💎 Pro botlar narxlari bilan tanishib chiqing:

1) 🖇 Join hider (ya'ni kirdi-chiqdilarni tozalovchi bot) - 10 ta olmos
2) Suhbatdosh (guruhda gaplashuvchi bot) - 12 ta olmos
3) 📈 Reyting bot (ya'ni guruh a'zolari reytingini (+/-) ko'rsatuvchi bot) - 14 ta olmos
4) 🛠 Sanovchi bot (ya'ni kim nechta odam qo'shganini sanovchi bot) - 16 ta olmos
5) 🔗 Join bot (ya'ni kanalga a'zo bo'lmasa guruhdagi a'zolarni yozishga qo'ymaydigan bot) - 18 ta olmos
6) 👮‍♂️ Posbon bot (ya'ni guruhni nazorat qiluvchi bot) - 20 ta olmos
7) ❤️ Channel like bot (ya'ni kanaldagi rasm, video, golos va h.k.larga like/dislike va ulashish tugmasini qo'yib beradigan bot) - 22 ta olmos
",
    'parse_mode'=>"markdown",
    'reply_markup'=>$back_menu
    ]);
}

if($tx == "📊 Statistika" and joinchat($fid)=="true"){
    $us = file_get_contents("stat/usid.txt");
    $uscount = substr_count($us, "\n");
    $bot = file_get_contents("stat/stat.txt");
    $botpro = file_get_contents("stat/statpro.txt");
    $all = $bot + $botpro;
    bot('sendMessage',[
    'chat_id' => $cid,
    'text'=>"📊 Statistika\nBot a'zolari soni: *$uscount* ta\nJami yasalgan oddiy botlar: *$bot* ta\nJami yasalgan pro botlar: *$botpro* ta\nJami yasalgan botlar: *$all* ta",
    'parse_mode'=>"markdown",
    'reply_markup'=>$back_menu
    ]);
}

if($tx == "ℹ️ Bot haqida" and joinchat($fid)=="true"){
   bot('sendMessage',[
    'chat_id' => $cid,
    'text'=>"ℹ️ Bot haqida\n\n✳️ Ushbu bot orqali siz hech qanday dasturlash tillarini bilmasdan turib va hech qanday hostinglarsiz oson bot yasay olasiz.\n♻️ Bot versiyasi: 1.03\n🔰 Mavjud oddiy botlar soni: *8* ta\nMavjud pro botlar soni: *7* ta\n👨‍💻 Dasturchi: @BekDev\n📲 Kanalimiz: @ESoftUz",
    'parse_mode'=>"markdown",
    'reply_markup'=>$back_menu
    ]);
}

//------- admin

if(($tx == "/panel" or $tx == "⬅️ Admin panel") and $cid == $admin){
    bot('deleteMessage',['chat_id'=>$cid,'message_id'=>$mid]);
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Admin panelga xush kelibsiz:",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"📤 Bot a'zolariga xabar yo'llash"]],
    [['text'=>"📤 Bot a'zolariga forward qilish"]],
    [['text'=>"🚫 Bloklash"],['text'=>"💎 Olmos berish"]],
    [['text'=>"📂 Bot code"]],
    [['text'=>"⬅️ Ortga"]]
    ]
    ])
    ]);
}

if($tx == "⬅️ Bekor"){
    unlink("step/admin.txt");
    bot('sendMessage',[
        'text'=>"<b>Bekor qilindi!</b>\nQuyidagi menyudan foydalaning: ",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"📤 Bot a'zolariga xabar yo'llash"]],
    [['text'=>"📤 Bot a'zolariga forward qilish"]],
    [['text'=>"🚫 Bloklash"],['text'=>"💎 Olmos berish"]],
    [['text'=>"📂 Bot code"]],
    [['text'=>"⬅️ Ortga"]]
    ]
    ])
    ]);
}

if($tx == "📤 Bot a'zolariga xabar yo'llash" and $cid == $admin){
    bot('sendMessage',[
        'text'=>"Bot a'zolariga yuboriladigan xabarni kiriting (markdown): ",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Bekor"]],
    ]
    ])
    ]);
    file_put_contents("step/admin.txt", "xabar");
}

if($adminstep == "xabar" and $tx !== "⬅️ Bekor" and $cid == $admin){
    $get = file_get_contents("stat/usid.txt");
    $ex = explode("\n", $get);
    foreach ($ex as $us) {
        bot('sendMessage',[
        'chat_id'=>$us,
        'text'=>$tx,
        'parse_mode'=>"markdown"
    ]);
    unlink("step/admin.txt");
    }
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Barcha a'zolarga yuborildi",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Admin panel"]],
    ]
    ])
    ]);
}

if($tx == "📤 Bot a'zolariga forward qilish" and $cid == $admin){
    bot('sendMessage',[
        'text'=>"Bot a'zolarigan forward qilinadigan xabarni yuboring: ",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Bekor"]],
    ]
    ])
    ]);
    file_put_contents("step/admin.txt", "forw");
}

if($adminstep == "forw" and $tx !== "⬅️ Bekor" and $cid == $admin){
    $get = file_get_contents("stat/usid.txt");
    $ex = explode("\n", $get);
    foreach ($ex as $us) {
        bot('forwardMessage',[
        'chat_id'=>$us,
        'from_chat_id'=>$admin,
        'message_id'=>$mid
    ]);
    unlink("step/admin.txt");
    }
    bot('sendMessage',[
    'chat_id'=>$admin,
    'text'=>"Barcha a'zolarga yuborildi",
    'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Admin panel"]],
    ]
    ])
    ]);
}

if($tx == "🚫 Bloklash" and $tx !== "⬅️ Bekor" and $cid == $admin){
bot('sendMessage',[
        'text'=>"Bloklanadigan user idsini yuboring:",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Bekor"]],
    ]
    ])
    ]);
    file_put_contents("step/admin.txt", "blok");    
}

if($adminstep == "blok" and $tx !== "⬅️ Bekor" and $cid == $admin){
    $get = file_get_contents("ban/banid.txt");
    if(mb_stripos($get, $tx)==false){
    	$gets = file_get_contents("stat/usid.txt");
    	$gets = str_replace("\n$tx", "", $gets);
    	file_put_contents("stat/usid.txt", $gets);
        file_put_contents("ban/banid.txt", "$get\n$tx");
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"User bloklandi",
        'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
        [['text'=>"⬅️ Admin panel"]],
        ]
        ])
        ]);
    unlink("step/admin.txt");
    }else{
        bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"User bloklangan edi, boshqa id yuboring yoki admin panelga qayting:",
        'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
        [['text'=>"⬅️ Admin panel"]],
        ]
        ])
        ]);
    }
}


if($tx == "💎 Olmos berish" and $tx !== "⬅️ Bekor" and $cid == $admin){
bot('sendMessage',[
        'text'=>"Olmos beriladigan userni quyidagicha yuboring:\n<code>0000001*10</code>",
        'chat_id'=>$admin,
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
    'resize_keyboard'=>true,
    'keyboard'=>[
    [['text'=>"⬅️ Bekor"]],
    ]
    ])
    ]);
    file_put_contents("step/admin.txt", "olmos");   
}

if($adminstep == "olmos" and $tx !== "⬅️ Bekor" and $cid == $admin){
    $ex = explode("*", $tx);
    $get = file_get_contents("referal/$ex[0].txt");
    $get += $ex[1];
    file_put_contents("referal/$ex[0].txt",$get);
    bot('sendMessage',[
        'chat_id'=>$ex[0],
        'text'=>"Tabriklaymiz sizga <b>$ex[1]</b> ta olmos berildi!",
        'parse_mode'=>"html"
        ]);
    unlink("step/admin.txt");
    bot('sendMessage',[
        'chat_id'=>$admin,
        'text'=>"<b>$ex[0]</b> id raqamli userga <b>$ex[1]</b> ta olmos berildi",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
        [['text'=>"⬅️ Admin panel"]],
        ]
        ])
        ]);
}

if($tx == "📂 Bot code" and $cid == $admin){
    bot('sendDocument',[
    'chat_id'=>$admin,
    'document'=>new CURLFile(__FILE__),
    'caption'=>"$botname kodi",
    'reply_markup'=>json_encode([
        'resize_keyboard'=>true,
        'keyboard'=>[
        [['text'=>"⬅️ Admin panel"]],
        ]
        ])
    ]);
}